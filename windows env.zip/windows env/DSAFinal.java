import java.util.*;

class DSAFinal {

    static class Node {
        int data, height;
        Node left, right;
        Node(int d) { data = d; height = 1; left = right = null; }
    }

    static int height(Node n) { return n == null ? 0 : n.height; }

    static int getBalance(Node n) { return n == null ? 0 : height(n.left) - height(n.right); }

    static Node rightRotate(Node y) {
        Node x = y.left;
        Node t2 = x.right;
        x.right = y;
        y.left = t2;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        return x;
    }

    static Node leftRotate(Node x) {
        Node y = x.right;
        Node t2 = y.left;
        y.left = x;
        x.right = t2;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        return y;
    }

    static Node bstInsert(Node root, int key) {
        if (root == null) return new Node(key);
        if (key < root.data) root.left = bstInsert(root.left, key);
        else if (key > root.data) root.right = bstInsert(root.right, key);
        return root;
    }

    static Node bstSearch(Node root, int key) {
        if (root == null || root.data == key) return root;
        if (key < root.data) return bstSearch(root.left, key);
        return bstSearch(root.right, key);
    }

    static Node minValueNode(Node node) {
        Node current = node;
        while (current.left != null) current = current.left;
        return current;
    }

    static Node bstDelete(Node root, int key) {
        if (root == null) return root;
        if (key < root.data) root.left = bstDelete(root.left, key);
        else if (key > root.data) root.right = bstDelete(root.right, key);
        else {
            if (root.left == null) return root.right;
            else if (root.right == null) return root.left;
            Node temp = minValueNode(root.right);
            root.data = temp.data;
            root.right = bstDelete(root.right, temp.data);
        }
        return root;
    }

    static Node avlInsert(Node node, int key) {
        if (node == null) return new Node(key);
        if (key < node.data) node.left = avlInsert(node.left, key);
        else if (key > node.data) node.right = avlInsert(node.right, key);
        else return node;

        node.height = 1 + Math.max(height(node.left), height(node.right));
        int balance = getBalance(node);

        if (balance > 1 && key < node.left.data) return rightRotate(node);
        if (balance < -1 && key > node.right.data) return leftRotate(node);
        if (balance > 1 && key > node.left.data) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }
        if (balance < -1 && key < node.right.data) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }
        return node;
    }

    static Node avlDelete(Node root, int key) {
        if (root == null) return root;
        if (key < root.data) root.left = avlDelete(root.left, key);
        else if (key > root.data) root.right = avlDelete(root.right, key);
        else {
            if (root.left == null || root.right == null) {
                Node temp = root.left != null ? root.left : root.right;
                if (temp == null) { root = null; }
                else root = temp;
            } else {
                Node temp = minValueNode(root.right);
                root.data = temp.data;
                root.right = avlDelete(root.right, temp.data);
            }
        }
        if (root == null) return root;

        root.height = Math.max(height(root.left), height(root.right)) + 1;
        int balance = getBalance(root);

        if (balance > 1 && getBalance(root.left) >= 0) return rightRotate(root);
        if (balance > 1 && getBalance(root.left) < 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }
        if (balance < -1 && getBalance(root.right) <= 0) return leftRotate(root);
        if (balance < -1 && getBalance(root.right) > 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }
        return root;
    }

    static void inorder(Node root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    static void preorder(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    static void postorder(Node root) {
        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }

    static void bfs(Node root) {
        if (root == null) return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node curr = queue.poll();
            System.out.print(curr.data + " ");
            if (curr.left != null) queue.add(curr.left);
            if (curr.right != null) queue.add(curr.right);
        }
    }

    static void dfs(Node root) {
        if (root == null) return;
        Stack<Node> stack = new Stack<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            Node curr = stack.pop();
            System.out.print(curr.data + " ");
            if (curr.right != null) stack.push(curr.right);
            if (curr.left != null) stack.push(curr.left);
        }
    }

    static class HuffmanNode implements Comparable<HuffmanNode> {
        int freq;
        char ch;
        HuffmanNode left, right;
        HuffmanNode(char ch, int freq) { this.ch = ch; this.freq = freq; left = right = null; }
        public int compareTo(HuffmanNode o) { return this.freq - o.freq; }
    }

    static void printHuffmanCodes(HuffmanNode root, String code) {
        if (root == null) return;
        if (root.left == null && root.right == null) {
            System.out.println("  '" + root.ch + "' => " + code);
            return;
        }
        printHuffmanCodes(root.left, code + "0");
        printHuffmanCodes(root.right, code + "1");
    }

    static void huffmanCoding(String text) {
        HashMap<Character, Integer> freqMap = new HashMap<>();
        for (char c : text.toCharArray()) freqMap.put(c, freqMap.getOrDefault(c, 0) + 1);

        PriorityQueue<HuffmanNode> pq = new PriorityQueue<>();
        for (Map.Entry<Character, Integer> entry : freqMap.entrySet())
            pq.add(new HuffmanNode(entry.getKey(), entry.getValue()));

        while (pq.size() > 1) {
            HuffmanNode left = pq.poll();
            HuffmanNode right = pq.poll();
            HuffmanNode parent = new HuffmanNode('-', left.freq + right.freq);
            parent.left = left;
            parent.right = right;
            pq.add(parent);
        }

        HuffmanNode root = pq.poll();
        System.out.println("  huffman codes generated....");
        printHuffmanCodes(root, "");
    }

    public static void main(String[] args) {

        System.out.println("======================================");
        System.out.println("  dsa final exam practice.... let's go");
        System.out.println("======================================\n");

        System.out.println("--- bst (binary search tree) stuff ---");
        System.out.println("inserting values into bst..... 50, 30, 70, 20, 40, 60, 80");
        Node bstRoot = null;
        int[] bstVals = {50, 30, 70, 20, 40, 60, 80};
        for (int v : bstVals) bstRoot = bstInsert(bstRoot, v);

        System.out.print("inorder traversal of bst...... ");
        inorder(bstRoot);
        System.out.println();

        System.out.print("preorder traversal...... ");
        preorder(bstRoot);
        System.out.println();

        System.out.print("postorder traversal...... ");
        postorder(bstRoot);
        System.out.println();

        int searchKey = 40;
        Node found = bstSearch(bstRoot, searchKey);
        System.out.println("searching for " + searchKey + " in bst...... " + (found != null ? "found it!" : "not found :("));

        searchKey = 99;
        found = bstSearch(bstRoot, searchKey);
        System.out.println("searching for " + searchKey + " in bst...... " + (found != null ? "found it!" : "not found :("));

        System.out.println("deleting 20 from bst.....");
        bstRoot = bstDelete(bstRoot, 20);
        System.out.print("inorder after deleting 20...... ");
        inorder(bstRoot);
        System.out.println();

        System.out.println("deleting 30 from bst..... (node with one child)");
        bstRoot = bstDelete(bstRoot, 30);
        System.out.print("inorder after deleting 30...... ");
        inorder(bstRoot);
        System.out.println();

        System.out.println("deleting 50 from bst..... (root node with two children)");
        bstRoot = bstDelete(bstRoot, 50);
        System.out.print("inorder after deleting 50...... ");
        inorder(bstRoot);
        System.out.println("\n");

        System.out.println("--- avl tree section ---");
        System.out.println("building avl tree..... inserting 10, 20, 30, 40, 50, 25");
        Node avlRoot = null;
        int[] avlVals = {10, 20, 30, 40, 50, 25};
        for (int v : avlVals) avlRoot = avlInsert(avlRoot, v);

        System.out.print("inorder of avl tree...... ");
        inorder(avlRoot);
        System.out.println();

        System.out.print("preorder of avl tree...... ");
        preorder(avlRoot);
        System.out.println();

        System.out.println("avl tree height is..... " + height(avlRoot));
        System.out.println("balance factor at root...... " + getBalance(avlRoot));

        System.out.println("deleting 40 from avl.....");
        avlRoot = avlDelete(avlRoot, 40);
        System.out.print("inorder after avl delete...... ");
        inorder(avlRoot);
        System.out.println();
        System.out.println("height after deletion..... " + height(avlRoot));
        System.out.println("balance at root now...... " + getBalance(avlRoot));
        System.out.println();

        System.out.println("--- bfs and dfs traversals ---");
        System.out.println("rebuilding a tree for traversal demo.....");
        Node travRoot = null;
        int[] travVals = {15, 10, 25, 5, 12, 20, 30};
        for (int v : travVals) travRoot = bstInsert(travRoot, v);

        System.out.print("bfs (level order) traversal...... ");
        bfs(travRoot);
        System.out.println();

        System.out.print("dfs (using stack) traversal...... ");
        dfs(travRoot);
        System.out.println();

        System.out.print("dfs recursive (preorder)...... ");
        preorder(travRoot);
        System.out.println();

        System.out.print("dfs recursive (inorder)...... ");
        inorder(travRoot);
        System.out.println();

        System.out.print("dfs recursive (postorder)...... ");
        postorder(travRoot);
        System.out.println("\n");

        System.out.println("--- huffman coding practical ---");
        String text = "abracadabra";
        System.out.println("input string for huffman...... \"" + text + "\"");
        System.out.println("building huffman tree now.....");
        huffmanCoding(text);

        System.out.println();
        String text2 = "hello world";
        System.out.println("trying another string...... \"" + text2 + "\"");
        huffmanCoding(text2);

        System.out.println();
        String text3 = "aaaaabbbbbccccdddeef";
        System.out.println("one more example...... \"" + text3 + "\"");
        System.out.println("frequency based encoding below.....");
        huffmanCoding(text3);

        System.out.println("\n======================================");
        System.out.println("  done with everything..... good luck on the exam!!");
        System.out.println("======================================");
    }
}
