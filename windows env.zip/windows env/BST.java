import java.util.*;

class BST {

    int data;
    BST left, right;

    BST(int data) {
        this.data = data;
        left = right = null;
    }

    static BST insert(BST root, int key) {
        if (root == null)
            return new BST(key);
        if (key < root.data)
            root.left = insert(root.left, key);
        else if (key > root.data)
            root.right = insert(root.right, key);
        return root;
    }

    static BST search(BST root, int key) {
        if (root == null || root.data == key)
            return root;
        if (key < root.data)
            return search(root.left, key);
        return search(root.right, key);
    }

    static BST minNode(BST root) {
        while (root.left != null)
            root = root.left;
        return root;
    }

    static BST delete(BST root, int key) {
        if (root == null)
            return null;
        if (key < root.data)
            root.left = delete(root.left, key);
        else if (key > root.data)
            root.right = delete(root.right, key);
        else {
            if (root.left == null)
                return root.right;
            if (root.right == null)
                return root.left;
            BST temp = minNode(root.right);
            root.data = temp.data;
            root.right = delete(root.right, temp.data);
        }
        return root;
    }

    static void inorder(BST root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    static void preorder(BST root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    static void postorder(BST root) {
        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BST root = null;
        int choice = 0;

        while (choice != 7) {

            System.out.println("\n===== bst menu =====");
            System.out.println("1. insert a value");
            System.out.println("2. delete a value");
            System.out.println("3. search a value");
            System.out.println("4. inorder traversal");
            System.out.println("5. preorder traversal");
            System.out.println("6. postorder traversal");
            System.out.println("7. exit");
            System.out.print("enter your choice...... ");
            choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("enter value to insert...... ");
                int val = sc.nextInt();
                root = insert(root, val);
                System.out.println(val + " inserted into bst.....");

            } else if (choice == 2) {
                System.out.print("enter value to delete...... ");
                int val = sc.nextInt();
                root = delete(root, val);
                System.out.println(val + " deleted from bst.....");

            } else if (choice == 3) {
                System.out.print("enter value to search...... ");
                int val = sc.nextInt();
                if (search(root, val) != null)
                    System.out.println(val + " found in bst.....");
                else
                    System.out.println(val + " not found in bst.....");

            } else if (choice == 4) {
                System.out.print("inorder...... ");
                inorder(root);
                System.out.println();

            } else if (choice == 5) {
                System.out.print("preorder...... ");
                preorder(root);
                System.out.println();

            } else if (choice == 6) {
                System.out.print("postorder...... ");
                postorder(root);
                System.out.println();

            } else if (choice == 7) {
                System.out.println("exiting bst program.....");
            }
        }
        sc.close();
    }
}
