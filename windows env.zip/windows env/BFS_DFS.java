import java.util.*;

class BFS_DFS {

    int data;
    BFS_DFS left, right;

    BFS_DFS(int data) {
        this.data = data;
        left = right = null;
    }

    static BFS_DFS insert(BFS_DFS root, int key) {
        if (root == null)
            return new BFS_DFS(key);
        if (key < root.data)
            root.left = insert(root.left, key);
        else
            root.right = insert(root.right, key);
        return root;
    }

    static void bfs(BFS_DFS root) {
        if (root == null) {
            System.out.println("tree is empty.....");
            return;
        }
        Queue<BFS_DFS> q = new LinkedList<>();
        q.add(root);
        while (!q.isEmpty()) {
            BFS_DFS curr = q.poll();
            System.out.print(curr.data + " ");
            if (curr.left != null) q.add(curr.left);
            if (curr.right != null) q.add(curr.right);
        }
        System.out.println();
    }

    static void dfsStack(BFS_DFS root) {
        if (root == null) {
            System.out.println("tree is empty.....");
            return;
        }
        Stack<BFS_DFS> s = new Stack<>();
        s.push(root);
        while (!s.isEmpty()) {
            BFS_DFS curr = s.pop();
            System.out.print(curr.data + " ");
            if (curr.right != null) s.push(curr.right);
            if (curr.left != null) s.push(curr.left);
        }
        System.out.println();
    }

    static void inorder(BFS_DFS root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    static void preorder(BFS_DFS root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    static void postorder(BFS_DFS root) {
        if (root != null) {
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BFS_DFS root = null;
        int choice = 0;

        while (choice != 7) {

            System.out.println("\n===== bfs & dfs menu =====");
            System.out.println("1. insert a value");
            System.out.println("2. bfs (level order)");
            System.out.println("3. dfs using stack");
            System.out.println("4. dfs inorder (recursive)");
            System.out.println("5. dfs preorder (recursive)");
            System.out.println("6. dfs postorder (recursive)");
            System.out.println("7. exit");
            System.out.print("enter your choice...... ");
            choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("enter value to insert...... ");
                int val = sc.nextInt();
                root = insert(root, val);
                System.out.println(val + " inserted.....");

            } else if (choice == 2) {
                System.out.print("bfs traversal...... ");
                bfs(root);

            } else if (choice == 3) {
                System.out.print("dfs (stack)...... ");
                dfsStack(root);

            } else if (choice == 4) {
                System.out.print("inorder...... ");
                inorder(root);
                System.out.println();

            } else if (choice == 5) {
                System.out.print("preorder...... ");
                preorder(root);
                System.out.println();

            } else if (choice == 6) {
                System.out.print("postorder...... ");
                postorder(root);
                System.out.println();

            } else if (choice == 7) {
                System.out.println("exiting bfs dfs program.....");
            }
        }
        sc.close();
    }
}
