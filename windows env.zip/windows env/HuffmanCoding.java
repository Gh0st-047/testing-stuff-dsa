import java.util.*;

class HuffmanCoding implements Comparable<HuffmanCoding> {

    int freq;
    char ch;
    HuffmanCoding left, right;

    HuffmanCoding(char ch, int freq) {
        this.ch = ch;
        this.freq = freq;
        left = right = null;
    }

    public int compareTo(HuffmanCoding other) {
        return this.freq - other.freq;
    }

    static void printCodes(HuffmanCoding root, String code) {
        if (root == null)
            return;
        if (root.left == null && root.right == null) {
            System.out.println("  '" + root.ch + "' -> " + code);
            return;
        }
        printCodes(root.left, code + "0");
        printCodes(root.right, code + "1");
    }

    static void buildAndPrint(String text) {

        int[] freq = new int[256];
        for (int i = 0; i < text.length(); i++) {
            freq[text.charAt(i)]++;
        }

        PriorityQueue<HuffmanCoding> pq = new PriorityQueue<>();

        for (int i = 0; i < 256; i++) {
            if (freq[i] > 0) {
                pq.add(new HuffmanCoding((char) i, freq[i]));
            }
        }

        while (pq.size() > 1) {
            HuffmanCoding left = pq.poll();
            HuffmanCoding right = pq.poll();
            HuffmanCoding parent = new HuffmanCoding('-', left.freq + right.freq);
            parent.left = left;
            parent.right = right;
            pq.add(parent);
        }

        HuffmanCoding root = pq.poll();
        printCodes(root, "");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice = 0;

        while (choice != 3) {

            System.out.println("\n===== huffman coding menu =====");
            System.out.println("1. enter a string and generate huffman codes");
            System.out.println("2. try example strings");
            System.out.println("3. exit");
            System.out.print("enter your choice...... ");
            choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {
                System.out.print("enter the string...... ");
                String text = sc.nextLine();
                System.out.println("building huffman tree for...... \"" + text + "\"");
                buildAndPrint(text);

            } else if (choice == 2) {
                System.out.println("\nexample 1...... \"abracadabra\"");
                buildAndPrint("abracadabra");

                System.out.println("\nexample 2...... \"hello world\"");
                buildAndPrint("hello world");

                System.out.println("\nexample 3...... \"aaaaabbbbbccccdddeef\"");
                buildAndPrint("aaaaabbbbbccccdddeef");

            } else if (choice == 3) {
                System.out.println("exiting huffman program.....");
            }
        }
        sc.close();
    }
}
