import java.util.*;

class AVLTree {

    int data, height;
    AVLTree left, right;

    AVLTree(int data) {
        this.data = data;
        this.height = 1;
        left = right = null;
    }

    static int height(AVLTree n) {
        if (n == null)
            return 0;
        return n.height;
    }

    static int balance(AVLTree n) {
        if (n == null)
            return 0;
        return height(n.left) - height(n.right);
    }

    static AVLTree rightRotate(AVLTree y) {
        AVLTree x = y.left;
        AVLTree t = x.right;
        x.right = y;
        y.left = t;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        return x;
    }

    static AVLTree leftRotate(AVLTree x) {
        AVLTree y = x.right;
        AVLTree t = y.left;
        y.left = x;
        x.right = t;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        return y;
    }

    static AVLTree insert(AVLTree node, int key) {
        if (node == null)
            return new AVLTree(key);

        if (key < node.data)
            node.left = insert(node.left, key);
        else if (key > node.data)
            node.right = insert(node.right, key);
        else
            return node;

        node.height = 1 + Math.max(height(node.left), height(node.right));
        int bal = balance(node);

        if (bal > 1 && key < node.left.data)
            return rightRotate(node);

        if (bal < -1 && key > node.right.data)
            return leftRotate(node);

        if (bal > 1 && key > node.left.data) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        if (bal < -1 && key < node.right.data) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }

    static AVLTree minNode(AVLTree root) {
        while (root.left != null)
            root = root.left;
        return root;
    }

    static AVLTree delete(AVLTree root, int key) {
        if (root == null)
            return null;

        if (key < root.data)
            root.left = delete(root.left, key);
        else if (key > root.data)
            root.right = delete(root.right, key);
        else {
            if (root.left == null || root.right == null) {
                if (root.left != null)
                    root = root.left;
                else
                    root = root.right;
            } else {
                AVLTree temp = minNode(root.right);
                root.data = temp.data;
                root.right = delete(root.right, temp.data);
            }
        }

        if (root == null)
            return null;

        root.height = Math.max(height(root.left), height(root.right)) + 1;
        int bal = balance(root);

        if (bal > 1 && balance(root.left) >= 0)
            return rightRotate(root);

        if (bal > 1 && balance(root.left) < 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }

        if (bal < -1 && balance(root.right) <= 0)
            return leftRotate(root);

        if (bal < -1 && balance(root.right) > 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }

    static void inorder(AVLTree root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.data + " ");
            inorder(root.right);
        }
    }

    static void preorder(AVLTree root) {
        if (root != null) {
            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        AVLTree root = null;
        int choice = 0;

        while (choice != 7) {

            System.out.println("\n===== avl tree menu =====");
            System.out.println("1. insert a value");
            System.out.println("2. delete a value");
            System.out.println("3. inorder traversal");
            System.out.println("4. preorder traversal");
            System.out.println("5. show height");
            System.out.println("6. show balance factor");
            System.out.println("7. exit");
            System.out.print("enter your choice...... ");
            choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("enter value to insert...... ");
                int val = sc.nextInt();
                root = insert(root, val);
                System.out.println(val + " inserted into avl tree.....");

            } else if (choice == 2) {
                System.out.print("enter value to delete...... ");
                int val = sc.nextInt();
                root = delete(root, val);
                System.out.println(val + " deleted from avl tree.....");

            } else if (choice == 3) {
                System.out.print("inorder...... ");
                inorder(root);
                System.out.println();

            } else if (choice == 4) {
                System.out.print("preorder...... ");
                preorder(root);
                System.out.println();

            } else if (choice == 5) {
                System.out.println("height of avl tree...... " + height(root));

            } else if (choice == 6) {
                System.out.println("balance factor at root...... " + balance(root));

            } else if (choice == 7) {
                System.out.println("exiting avl program.....");
            }
        }
        sc.close();
    }
}
